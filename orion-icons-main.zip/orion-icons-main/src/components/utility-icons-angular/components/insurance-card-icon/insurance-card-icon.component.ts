import { ChangeDetectionStrategy, Component, Input, OnChanges, SimpleChanges, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'orion-insurance-card-icon',
  templateUrl: './insurance-card-icon.component.html',
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class InsuranceCardIconComponent implements OnChanges {
  @Input() size: '' | '16' | '24' | '36' | '48' = '24';

  ngOnChanges(changes: SimpleChanges): void {}
}