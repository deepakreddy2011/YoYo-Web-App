import { ChangeDetectionStrategy, Component, Input, OnChanges, SimpleChanges, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'orion-chevronRight-icon',
  templateUrl: './chevronRight-icon.component.html',
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ChevronRightIconComponent implements OnChanges {
  @Input() size: '' | '16' | '24' | '36' | '48' = '24';
  
  ngOnChanges(changes: SimpleChanges): void {}
}