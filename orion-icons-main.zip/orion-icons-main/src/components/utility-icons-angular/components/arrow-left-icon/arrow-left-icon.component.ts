import { ChangeDetectionStrategy, Component, Input, OnChanges, SimpleChanges, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'orion-arrow-left-icon',
  templateUrl: './arrow-left-icon.component.html',
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ArrowLeftIconComponent implements OnChanges {
  @Input() size: '' | '16' | '24' | '36' | '48' = '24';

  ngOnChanges(changes: SimpleChanges): void {}
}