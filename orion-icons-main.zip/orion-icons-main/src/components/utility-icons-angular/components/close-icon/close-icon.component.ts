import { ChangeDetectionStrategy, Component, Input, OnChanges, SimpleChanges, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'orion-close-icon',
  templateUrl: './close-icon.component.html',
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CloseIconComponent implements OnChanges {
  @Input() size: '' | '16' | '24' | '36' | '48' = '24';

  ngOnChanges(changes: SimpleChanges): void {}
}