# IconsLibrary

This library was generated with [Angular CLI](https://github.com/angular/angular-cli) version 12.2.0.

## Install
`cd src/components/utility-icons-angular` and run `npm i` to generate node_modules.

## Build

Run `ng build @optum/orion-icons-angular` to build the project. The build artifacts will be stored in the `dist/` directory.

## Export newly generated components

Export the newly generated angular svg components in utility-icons-angular.module.ts and public-api.ts and then run 
`ng build @optum/orion-icons-angular` so that the newly generated components are available in library.

## Publishing

After building your library with `ng build @optum/orion-icons-angular`, go to the dist folder `cd dist` and run `npm publish`.

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.
