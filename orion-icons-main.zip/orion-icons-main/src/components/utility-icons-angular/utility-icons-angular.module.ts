import { Injector, NgModule } from '@angular/core';
import { AccountIconComponent } from './components/account-icon/account-icon.component';
import { ArrowLeftIconComponent } from './components/arrow-left-icon/arrow-left-icon.component';
import { ArrowRightIconComponent } from './components/arrow-right-icon/arrow-right-icon.component';
import { ChevronDownIconComponent } from './components/chevron-down-icon/chevron-down-icon.component';
import { ChevronLeftIconComponent } from './components/chevron-left-icon/chevron-left-icon.component';
import { ChevronRightIconComponent } from './components/chevron-right-icon/chevron-right-icon.component';
import { ChevronUpIconComponent } from './components/chevron-up-icon/chevron-up-icon.component';
import { CloseIconComponent } from './components/close-icon/close-icon.component';
import { DateIconComponent } from './components/date-icon/date-icon.component';
import { DownloadIconComponent } from './components/download-icon/download-icon.component';
import { EditIconComponent } from './components/edit-icon/edit-icon.component';
import { ErrorIconComponent } from './components/error-icon/error-icon.component';
import { FacebookIconComponent } from './components/facebook-icon/facebook-icon.component';
import { FilterIconComponent } from './components/filter-icon/filter-icon.component';
import { HelpIconComponent } from './components/help-icon/help-icon.component';
import { InfoIconComponent } from './components/info-icon/info-icon.component';
import { InstagramIconComponent } from './components/instagram-icon/instagram-icon.component';
import { InsuranceCardIconComponent } from './components/insurance-card-icon/insurance-card-icon.component';
import { LinkedinIconComponent } from './components/linkedin-icon/linkedin-icon.component';
import { MenuIconComponent } from './components/menu-icon/menu-icon.component';
import { NotificationsIconComponent } from './components/notifications-icon/notifications-icon.component';
import { OpenInNewIconComponent } from './components/open-in-new-icon/open-in-new-icon.component';
import { PlaceIconComponent } from './components/place-icon/place-icon.component';
import { SearchIconComponent } from './components/search-icon/search-icon.component';
import { SettingsIconComponent } from './components/settings-icon/settings-icon.component';
import { SortIconComponent } from './components/sort-icon/sort-icon.component';
import { SyncIconComponent } from './components/sync-icon/sync-icon.component';
import { TimeIconComponent } from './components/time-icon/time-icon.component';
import { TwitterIconComponent } from './components/twitter-icon/twitter-icon.component';
import { UploadIconComponent } from './components/upload-icon/upload-icon.component';
import { YoutubeIconComponent } from './components/youtube-icon/youtube-icon.component';
import { createCustomElement } from '@angular/elements';


@NgModule({
  declarations: [
    AccountIconComponent,
    ArrowLeftIconComponent,
    ArrowRightIconComponent,
    ChevronDownIconComponent,
    ChevronLeftIconComponent,
    ChevronRightIconComponent,
    ChevronUpIconComponent,
    CloseIconComponent,
    DateIconComponent,
    DownloadIconComponent,
    EditIconComponent,
    ErrorIconComponent,
    FacebookIconComponent,
    FilterIconComponent,
    HelpIconComponent,
    InfoIconComponent,
    InstagramIconComponent,
    InsuranceCardIconComponent,
    LinkedinIconComponent,
    MenuIconComponent,
    NotificationsIconComponent,
    OpenInNewIconComponent,
    PlaceIconComponent,
    SearchIconComponent,
    SettingsIconComponent,
    SortIconComponent,
    SyncIconComponent,
    TimeIconComponent,
    TwitterIconComponent,
    UploadIconComponent,
    YoutubeIconComponent
  ],
  imports: [
  ],
  exports: [
    AccountIconComponent,
    ArrowLeftIconComponent,
    ArrowRightIconComponent,
    ChevronDownIconComponent,
    ChevronLeftIconComponent,
    ChevronRightIconComponent,
    ChevronUpIconComponent,
    CloseIconComponent,
    DateIconComponent,
    DownloadIconComponent,
    EditIconComponent,
    ErrorIconComponent,
    FacebookIconComponent,
    FilterIconComponent,
    HelpIconComponent,
    InfoIconComponent,
    InstagramIconComponent,
    InsuranceCardIconComponent,
    LinkedinIconComponent,
    MenuIconComponent,
    NotificationsIconComponent,
    OpenInNewIconComponent,
    PlaceIconComponent,
    SearchIconComponent,
    SettingsIconComponent,
    SortIconComponent,
    SyncIconComponent,
    TimeIconComponent,
    TwitterIconComponent,
    UploadIconComponent,
    YoutubeIconComponent
  ],
  entryComponents: []
})
export class UtilityIconsAngularModule { 
  constructor(private injector: Injector) {
    
  }

  ngDoBootstrap(){}
}
