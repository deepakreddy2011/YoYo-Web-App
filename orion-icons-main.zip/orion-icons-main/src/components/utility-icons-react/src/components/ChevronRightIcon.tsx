import React from 'react';
import {IconProps} from '../interface/icon';

const ChevronRightIcon: React.FunctionComponent<IconProps> = (props) => {
  const { size, ...other } = props;

  return <svg xmlns="http://www.w3.org/2000/svg" height={size} width={size} viewBox="0 0 24 24" {...other}><path d="M9.29 6.71a.996.996 0 0 0 0 1.41L13.17 12l-3.88 3.88a.996.996 0 1 0 1.41 1.41l4.59-4.59a.996.996 0 0 0 0-1.41L10.7 6.7c-.38-.38-1.02-.38-1.41.01z"/></svg>

};

ChevronRightIcon.defaultProps = {
  size: '24'
} as Partial<IconProps>;

export default ChevronRightIcon;
