import React from 'react';
import {IconProps} from '../interface/icon';

const InsuranceCardIcon: React.FunctionComponent<IconProps> = (props) => {
  const { size, ...other } = props;

  return <svg xmlns="http://www.w3.org/2000/svg" height={size} width={size} viewBox="0 0 24 24" {...other}><path d="M20 4a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h16Zm0 2H4v12h16V6Zm-2 8v2H6v-2h12Zm-8-6v4H6V8h4Zm4 3v1h-2v-1h2Zm4 0v1h-2v-1h2ZM9 9H7v2h2V9Zm5-1v1h-2V8h2Zm4 0v1h-2V8h2Z"/></svg>

};

InsuranceCardIcon.defaultProps = {
  size: '24'
} as Partial<IconProps>;

export default InsuranceCardIcon;
