import React from 'react';
import {IconProps} from '../interface/icon';

const ChevronUpIcon: React.FunctionComponent<IconProps> = (props) => {
  const { size, ...other } = props;

  return <svg xmlns="http://www.w3.org/2000/svg" height={size} width={size} viewBox="0 0 24 24" {...other}><path d="M11.29 8.71 6.7 13.3a.996.996 0 1 0 1.41 1.41L12 10.83l3.88 3.88a.996.996 0 1 0 1.41-1.41L12.7 8.71a.996.996 0 0 0-1.41 0z"/></svg>

};

ChevronUpIcon.defaultProps = {
  size: '24'
} as Partial<IconProps>;

export default ChevronUpIcon;
