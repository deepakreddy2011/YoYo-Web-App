import * as React from 'react'
import styles from './styles.module.css';
import AccountIcon from './components/AccountIcon';
import ArrowLeftIcon from './components/ArrowLeftIcon';
import ArrowRightIcon from './components/ArrowRightIcon';

interface Props {
  text: string
}

export const ExampleComponent = ({ text }: Props) => {
  return <div className={styles.test}>Example Component: {text}</div>
}

export {
  AccountIcon,
  ArrowLeftIcon,
  ArrowRightIcon
}

export default AccountIcon


