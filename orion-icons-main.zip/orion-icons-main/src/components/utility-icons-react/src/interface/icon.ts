type size = '16' | '24' | '32' | '64';

export interface IconProps{
    size?: size;
}