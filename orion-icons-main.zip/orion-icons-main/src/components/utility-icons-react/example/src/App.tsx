import React from 'react';
import '@orion/orion-icons-react/dist/index.css';

import account from '@optum/orion-icons-svgs/account.svg';
import arrow_left from '@optum/orion-icons-svgs/arrow_left.svg';
import arrow_right from '@optum/orion-icons-svgs/arrow_right.svg';

import { AccountIcon, ArrowLeftIcon , ArrowRightIcon } from '@orion/orion-icons-react';

const App = () => {
  return (
    <div className="App">
      <h1>Orion-Icons Preview</h1>
      <article className="iconTable">
        <section className="leftMargin"></section>
        <table>
          <tr>
            <th>Icon Name</th>
            <th>SVG</th>
            <th>React</th>
            <th>Angular</th>
          </tr>
          <hr />
          <tr>
            <td>Account Icon</td>
            <td><img src={account} alt="account icon" /></td>
            <td><AccountIcon /></td>
            <td>[rendered Angular component]</td>
          </tr>
          <tr>
            <td>Arrow Left Icon</td>
            <td><img src={arrow_left} alt="arrow left icon" /></td>
            <td><ArrowLeftIcon /></td>
            <td>[rendered Angular component]</td>
          </tr>
          <tr>
            <td>Arrow Right Icon</td>
            <td><img src={arrow_right} alt="arrow right icon" /></td>
            <td><ArrowRightIcon /></td>
            <td>[rendered Angular component]</td>
          </tr>
        </table>
        <section className="rightMargin"></section>
      </article>
    </div>
  )
}

export default App
