# utility-icons-react

> The Orion Design Systems utility icon library

[![NPM](https://img.shields.io/npm/v/utility-icons-react.svg)](https://www.npmjs.com/package/utility-icons-react) [![JavaScript Style Guide](https://img.shields.io/badge/code_style-standard-brightgreen.svg)](https://standardjs.com)

## Install

```bash
npm install --save utility-icons-react
```

## Usage

```tsx
import React, { Component } from 'react'

import MyComponent from 'utility-icons-react'
import 'utility-icons-react/dist/index.css'

class Example extends Component {
  render() {
    return <MyComponent />
  }
}
```

## License

MIT © [](https://github.com/)
