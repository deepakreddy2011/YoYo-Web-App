exports.angularComponentModule = (fileName, componentName) => `import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';

import { ${componentName}Component } from './${fileName}.component';

@NgModule({
  declarations: [${componentName}Component],
  imports: [CommonModule],
  exports: [${componentName}Component],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class ${componentName}Module {}
`;