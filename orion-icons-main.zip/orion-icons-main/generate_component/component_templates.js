exports.component = (name, content) => `import React from 'react';
import {IconProps} from '../interface/icon';

const ${name}: React.FunctionComponent<IconProps> = (props) => {
  const { size, ...other } = props;

  return ${content}
};

${name}.defaultProps = {
  size: '24'
} as Partial<IconProps>;

export default ${name};
`;