const fs = require('fs');
const path = require('path');
const { component } = require('./component_templates.js');
const { angularComponentHtml } = require('./angular_component_html');
const { angularComponentModule } = require('./angular_component_module');
const { angularComponent } = require('./angular_component');

function generateComponent(file) {
  const name = path.parse(file).name;
  const componentName = `${name.toLowerCase().replace(/[^a-zA-Z0-9]+(.)/g, (m, chr) => chr.toUpperCase())}`;
  const reactComponentName = `${componentName[0].toUpperCase()}${componentName.slice(1)}Icon`;
  const angularFileName = `${name.replace(/_/g,'-')}-icon`;
  const angularComponentDirectory = `${angularDir}/${angularFileName}`;

  const svgContent = fs.readFileSync(`${svgDir}${file}`, { encoding: 'utf8', flag: 'r' });
  const reactSvgContent = svgContent.replace('height="24"', 'height={size}').replace('width="24"', 'width={size}').replace('>', ' {...other}>');
  const angularSvgContent = svgContent.replace('height="24"', '[attr.height]="size"').replace('width="24"', '[attr.width]="size"');

  function writeFileErrorHandler(err, msg) {
    if (err) throw err;
    console.log(msg)
  }

  // react component
  fs.writeFile(`${reactDir}/${reactComponentName}.tsx`, component(reactComponentName, reactSvgContent), (err) => writeFileErrorHandler(err, `${file} converted into react component successfully`));

  // angular component
  if (!fs.existsSync(angularComponentDirectory)) fs.mkdirSync(angularComponentDirectory);

  fs.writeFile(`${angularComponentDirectory}/${angularFileName}.component.html`, angularComponentHtml(angularSvgContent), (err) => writeFileErrorHandler(err, `${file} converted into component html successfully`));
  fs.writeFile(`${angularComponentDirectory}/${angularFileName}.component.ts`, angularComponent(angularFileName, reactComponentName), (err) => writeFileErrorHandler(err, `${file} converted into angular component successfully`));
  fs.writeFile(`${angularComponentDirectory}/${angularFileName}.module.ts`, angularComponentModule(angularFileName, reactComponentName), (err) => writeFileErrorHandler(err, `${file} converted into component module successfully`));
}

// grab svg name from terminal argument
const [svgName] = process.argv.slice(2);

const reactDir = `./src/components/utility-icons-react/src/components`;
const angularDir = `./src/components/utility-icons-angular/components`;
const svgDir = './src/svgs/';
if (svgName) {
  generateComponent(svgName);
} else {
  fs.readdir(svgDir, function (err, files) {
    //handling error
    if (err) {
      return console.log('Unable to scan directory: ' + err);
    }
    //listing all files using forEach
    files.forEach(function (file) {
      if (file.includes('.svg')) {
        generateComponent(file);
      }
    });
  });
}
