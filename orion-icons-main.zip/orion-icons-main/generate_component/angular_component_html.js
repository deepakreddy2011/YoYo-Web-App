exports.angularComponentHtml = (content) => `<ng-container>
    <span aria-hidden="true"></span>
    ${content}
    <ng-content></ng-content>
</ng-container>
`;